numbers = [11, 21, 19, 30, 46]

for element in numbers:
    print(str(element * element))


