numbers <- c(11, 21, 19, 30, 46)

for(element in numbers){
    print(element*element)
}